import React from "react";
import "./notFound.scss";

export default function NotFound() {
  return (
    <div className="not__found__page">
      <h2>Page Not Found</h2>
    </div>
  );
}
