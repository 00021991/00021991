// export const base_url = "http://localhost:4000";
export const base_url = "https://course-project-6tty.onrender.com";
